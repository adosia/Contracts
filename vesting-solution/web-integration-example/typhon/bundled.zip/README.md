Start the webserver

```
bash webserver.sh
```

requires python3. It will open the index.html file at

```
Serving HTTP on 0.0.0.0 port 8000 (http://0.0.0.0:8000/)
```

